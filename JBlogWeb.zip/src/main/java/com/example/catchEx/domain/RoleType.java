package com.example.catchEx.domain;

public enum RoleType {
	USER, ADMIN;
}
