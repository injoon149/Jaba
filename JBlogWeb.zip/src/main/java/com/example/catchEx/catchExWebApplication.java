package com.example.catchEx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class catchExWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(catchExWebApplication.class, args);
	}

}
