package com.example.catchEx.exception;

public class JBlogException extends RuntimeException{
	private static final long serialVersionUID = 1L;
	
	public JBlogException(String message) {
		super(message);
	}

}
